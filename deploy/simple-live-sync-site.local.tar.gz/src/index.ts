import { DurableObjectSqlAdapter } from "./metrics-cloudflare.js";
import {
  createFailOpenMetricsSink,
  createMetricRecord,
  normalizeCountryCode,
  normalizeRegionCode,
  type ConnectionContext,
  type MetricsEvent,
  type MetricsSink,
  type UsageMetricEventType
} from "./metrics.js";
import { SqlMetricsStore } from "./metrics-store.js";
import { isStatsApiPath, queryStatsApi, STATS_CACHE_CONTROL } from "./stats-api.js";

export interface Env {
  ROOMS: DurableObjectNamespace;
  METRICS: DurableObjectNamespace;
  ASSETS: Fetcher;
  IP_HASH_SECRET?: string;
  SELF_ORIGIN?: string;
  METRICS_ENABLED?: string;
}

type ClientInfo = {
  app: string;
  platform: string;
  version: string;
};

type RoomUser = ClientInfo & {
  connectionId: string;
  shortId: string;
  isCreator: boolean;
};

type SyncRequest = {
  type?: string;
  roomId?: string;
  requestId?: string;
  payload?: unknown;
};

type ClientSession = {
  socket: WebSocket;
  user: RoomUser;
  roomId: string;
};

export const VERSION = "0.1.0";
export const DEFAULT_SERVICE_ORIGIN = "https://sync.furry.mo.cn";
export const ROOM_TTL_MS = 600_000;
export const HEARTBEAT_TIMEOUT_MS = 45_000;
export const MAX_ROOM_CLIENTS = 8;
export const MAX_MESSAGE_BYTES = 1024 * 1024;
const ROOM_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

const SEND_EVENT_BY_ACTION: Record<string, string> = {
  sendFavorite: "favoriteReceived",
  sendHistory: "historyReceived",
  sendShieldWord: "shieldWordReceived",
  sendBiliAccount: "biliAccountReceived"
};

const METRIC_EVENT_BY_ACTION: Record<string, UsageMetricEventType> = {
  sendFavorite: "send_favorite",
  sendHistory: "send_history",
  sendShieldWord: "send_shield_word",
  sendBiliAccount: "send_bili_account"
};

const INTERNAL_VISITOR_HEADER = "x-simple-live-visitor";
const INTERNAL_COUNTRY_HEADER = "x-simple-live-country";
const INTERNAL_REGION_HEADER = "x-simple-live-region";

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/") {
      return html(renderHomePage(url.origin));
    }
    if (url.pathname === "/stats" || url.pathname === "/stats/") {
      return env.ASSETS.fetch(assetRequest(request, "/stats.html"));
    }
    if (url.pathname === "/assets/app.js") {
      return javascript(renderAppScript());
    }
    if (url.pathname.startsWith("/assets/")) {
      return env.ASSETS.fetch(request);
    }
    if (url.pathname === "/health") {
      if (wantsHtml(request, url)) {
        return html(renderHealthPage(url.origin));
      }
      return json(buildHealthPayload());
    }
    if (isStatsApiPath(url.pathname)) {
      const methodError = statsMethodError(request.method);
      if (methodError) {
        return methodError;
      }
      if (!metricsEnabled(env)) {
        return json(
          { status: false, message: "statistics are temporarily unavailable" },
          503,
          "no-store"
        );
      }
      try {
        return await metricsStub(env).fetch(request);
      } catch (error) {
        console.error("Metrics API unavailable", stringifyError(error));
        return json(
          { status: false, message: "statistics are temporarily unavailable" },
          503,
          "no-store"
        );
      }
    }
    if (url.pathname !== "/sync") {
      return json({ status: false, message: "not found" }, 404);
    }
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return json({ status: false, message: "websocket upgrade required" }, 426);
    }
    const context = await cloudflareConnectionContext(request, env);
    const headers = new Headers(request.headers);
    headers.delete(INTERNAL_VISITOR_HEADER);
    headers.set(INTERNAL_COUNTRY_HEADER, context.countryCode ?? "ZZ");
    headers.set(INTERNAL_REGION_HEADER, context.regionCode ?? "");
    if (context.visitorHash) {
      headers.set(INTERNAL_VISITOR_HEADER, context.visitorHash);
    }
    const id = env.ROOMS.idFromName("global-room-hub");
    return env.ROOMS.get(id).fetch(new Request(request, { headers }));
  },

  async scheduled(_controller: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    if (!metricsEnabled(env)) {
      return;
    }
    ctx.waitUntil(
      metricsStub(env)
        .fetch("https://metrics.internal/internal/probe", { method: "POST" })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`availability probe returned ${response.status}`);
          }
        })
        .catch((error) => console.error("Availability probe failed", stringifyError(error)))
    );
  }
};

type RoomHubOptions = {
  roomTtlMs?: number;
  heartbeatTimeoutMs?: number;
  sweepIntervalMs?: number;
  maxRoomClients?: number;
  maxMessageBytes?: number;
  metricsSink?: MetricsSink;
};

export class RoomHubCore {
  private readonly sessions = new Map<WebSocket, ClientSession>();
  private readonly rooms = new Map<string, Set<WebSocket>>();
  private readonly roomCreators = new Map<string, WebSocket>();
  private readonly roomExpiresAt = new Map<string, number>();
  private readonly lastSeen = new Map<WebSocket, number>();
  private readonly connectionContexts = new Map<WebSocket, ConnectionContext>();
  private readonly roomTtlMs: number;
  private readonly heartbeatTimeoutMs: number;
  private readonly sweepIntervalMs: number;
  private readonly maxRoomClients: number;
  private readonly maxMessageBytes: number;
  private readonly metricsSink: MetricsSink;
  private heartbeatTimer?: ReturnType<typeof setInterval>;

  constructor(options: RoomHubOptions = {}) {
    this.roomTtlMs = options.roomTtlMs ?? ROOM_TTL_MS;
    this.heartbeatTimeoutMs = options.heartbeatTimeoutMs ?? HEARTBEAT_TIMEOUT_MS;
    this.sweepIntervalMs = options.sweepIntervalMs ?? 10_000;
    this.maxRoomClients = options.maxRoomClients ?? MAX_ROOM_CLIENTS;
    this.maxMessageBytes = options.maxMessageBytes ?? MAX_MESSAGE_BYTES;
    this.metricsSink = createFailOpenMetricsSink(options.metricsSink ?? { record() {} });
  }

  attachSocket(
    socket: WebSocket,
    attachEventListeners = true,
    connectionContext: ConnectionContext = {}
  ): void {
    this.lastSeen.set(socket, Date.now());
    this.connectionContexts.set(socket, connectionContext);
    this.ensureHeartbeat();
    if (!attachEventListeners) {
      return;
    }
    socket.addEventListener("message", (event) => {
      this.handleSocketMessage(socket, event.data).catch((error) => {
        this.sendError(socket, undefined, "serverError", stringifyError(error));
      });
    });
    socket.addEventListener("close", () => this.removeSocket(socket));
    socket.addEventListener("error", () => this.removeSocket(socket));
  }

  async handleSocketMessage(socket: WebSocket, raw: unknown): Promise<void> {
    if (typeof raw !== "string") {
      this.sendError(socket, undefined, "invalidMessage", "message must be text");
      return;
    }
    if (new TextEncoder().encode(raw).byteLength > this.maxMessageBytes) {
      this.sendError(socket, undefined, "payloadTooLarge", "message is larger than 1 MB");
      return;
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      this.sendError(socket, undefined, "invalidJson", "message is not valid JSON");
      return;
    }
    if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
      this.sendError(socket, undefined, "invalidMessage", "message must be a JSON object");
      return;
    }
    const message = parsed as SyncRequest;
    this.lastSeen.set(socket, Date.now());
    switch (message.type) {
      case "ping":
        this.send(socket, { type: "pong", requestId: message.requestId, serverTime: Date.now() });
        return;
      case "createRoom":
        this.createRoom(socket, message);
        return;
      case "joinRoom":
        this.joinRoom(socket, message);
        return;
      case "sendFavorite":
      case "sendHistory":
      case "sendShieldWord":
      case "sendBiliAccount":
        this.forwardContent(socket, message, message.type);
        return;
      case "leaveRoom":
        this.detachSocketFromRoom(socket);
        return;
      default:
        this.sendError(socket, message.requestId, "unknownType", "unknown message type");
    }
  }

  private createRoom(socket: WebSocket, message: SyncRequest): void {
    const info = parseClientInfo(message.payload);
    if (!info) {
      this.sendError(socket, message.requestId, "invalidClient", "client info is invalid");
      return;
    }
    this.detachSocketFromRoom(socket, false);
    this.lastSeen.set(socket, Date.now());
    const roomId = this.generateRoomId();
    const user = this.createRoomUser(info, true);
    this.rooms.set(roomId, new Set([socket]));
    this.roomCreators.set(roomId, socket);
    this.roomExpiresAt.set(roomId, Date.now() + this.roomTtlMs);
    this.sessions.set(socket, { socket, user, roomId });
    this.send(socket, {
      type: "roomCreated",
      requestId: message.requestId,
      roomId,
      expiresIn: Math.floor(this.roomTtlMs / 1000),
      user
    });
    this.broadcastUserUpdated(roomId);
    this.recordMetric(socket, "room_created");
  }

  private joinRoom(socket: WebSocket, message: SyncRequest): void {
    const roomId = normalizeRoomId(message.roomId);
    const info = parseClientInfo(message.payload);
    if (!roomId || !this.rooms.has(roomId)) {
      this.sendError(socket, message.requestId, "roomNotFound", "room not found");
      return;
    }
    if (this.isRoomExpired(roomId)) {
      this.destroyRoom(roomId, "expired");
      this.sendError(socket, message.requestId, "roomExpired", "room expired");
      return;
    }
    if (!info) {
      this.sendError(socket, message.requestId, "invalidClient", "client info is invalid");
      return;
    }
    const room = this.rooms.get(roomId)!;
    const existingSession = this.sessions.get(socket);
    if (existingSession?.roomId === roomId && room.has(socket)) {
      this.send(socket, {
        type: "roomJoined",
        requestId: message.requestId,
        roomId,
        expiresIn: Math.max(
          0,
          Math.floor((this.roomExpiresAt.get(roomId)! - Date.now()) / 1000)
        ),
        user: existingSession.user
      });
      return;
    }
    if (room.size >= this.maxRoomClients) {
      this.sendError(socket, message.requestId, "roomFull", "room is full");
      return;
    }
    this.detachSocketFromRoom(socket, false);
    this.lastSeen.set(socket, Date.now());
    const user = this.createRoomUser(info, false);
    room.add(socket);
    this.sessions.set(socket, { socket, user, roomId });
    this.send(socket, {
      type: "roomJoined",
      requestId: message.requestId,
      roomId,
      expiresIn: Math.max(0, Math.floor((this.roomExpiresAt.get(roomId)! - Date.now()) / 1000)),
      user
    });
    this.broadcastUserUpdated(roomId);
    this.recordMetric(socket, "room_joined");
  }

  private forwardContent(socket: WebSocket, message: SyncRequest, action: string): void {
    const roomId = normalizeRoomId(message.roomId);
    if (!roomId || !this.rooms.has(roomId)) {
      this.sendError(socket, message.requestId, "roomNotFound", "room not found");
      return;
    }
    if (this.isRoomExpired(roomId)) {
      this.destroyRoom(roomId, "expired");
      this.sendError(socket, message.requestId, "roomExpired", "room expired");
      return;
    }
    const sender = this.sessions.get(socket);
    if (!sender || !this.rooms.get(roomId)!.has(socket)) {
      this.sendError(socket, message.requestId, "notInRoom", "client is not in this room");
      return;
    }
    const payload = parseSyncPayload(message.payload);
    if (!payload) {
      this.sendError(socket, message.requestId, "invalidPayload", "sync payload is invalid");
      return;
    }
    const eventType = SEND_EVENT_BY_ACTION[action];
    for (const target of this.rooms.get(roomId)!) {
      if (target === socket) {
        continue;
      }
      this.send(target, {
        type: eventType,
        roomId,
        payload,
        from: sender.user
      });
    }
    this.send(socket, {
      type: "ack",
      requestId: message.requestId,
      action,
      roomId
    });
    this.recordMetric(socket, METRIC_EVENT_BY_ACTION[action]);
  }

  removeSocket(socket: WebSocket, notify = true): void {
    this.detachSocketFromRoom(socket, notify);
    this.lastSeen.delete(socket);
    this.connectionContexts.delete(socket);
  }

  private detachSocketFromRoom(socket: WebSocket, notify = true): void {
    const roomId = this.findRoomBySocket(socket);
    this.sessions.delete(socket);
    if (!roomId) {
      return;
    }
    const creator = this.roomCreators.get(roomId);
    if (creator === socket) {
      this.destroyRoom(roomId, "creatorDisconnected");
      return;
    }
    const room = this.rooms.get(roomId);
    room?.delete(socket);
    if (!room || room.size === 0) {
      this.rooms.delete(roomId);
      this.roomExpiresAt.delete(roomId);
      this.roomCreators.delete(roomId);
      return;
    }
    if (notify) {
      this.broadcastUserUpdated(roomId);
    }
  }

  private destroyRoom(roomId: string, reason: string): void {
    const room = this.rooms.get(roomId);
    if (!room) {
      return;
    }
    for (const socket of room) {
      this.send(socket, { type: "roomDestroyed", roomId, reason });
      this.sessions.delete(socket);
    }
    this.rooms.delete(roomId);
    this.roomCreators.delete(roomId);
    this.roomExpiresAt.delete(roomId);
  }

  private broadcastUserUpdated(roomId: string): void {
    const room = this.rooms.get(roomId);
    if (!room) {
      return;
    }
    const users = [...room]
      .map((socket) => this.sessions.get(socket)?.user)
      .filter((user): user is RoomUser => Boolean(user));
    for (const socket of room) {
      const currentUser = this.sessions.get(socket)?.user;
      this.send(socket, {
        type: "userUpdated",
        roomId,
        users: users.map((user) => ({
          ...user,
          isSelf: user.connectionId === currentUser?.connectionId
        }))
      });
    }
  }

  private ensureHeartbeat(): void {
    if (this.heartbeatTimer) {
      return;
    }
    this.heartbeatTimer = setInterval(() => {
      const now = Date.now();
      for (const [socket, lastSeenAt] of this.lastSeen.entries()) {
        if (now - lastSeenAt > this.heartbeatTimeoutMs) {
          this.send(socket, { type: "roomDestroyed", reason: "heartbeatTimeout" });
          this.safeClose(socket, 1001, "heartbeat timeout");
          this.removeSocket(socket);
        }
      }
      for (const [roomId] of this.rooms) {
        if (this.isRoomExpired(roomId)) {
          this.destroyRoom(roomId, "expired");
        }
      }
      if (this.lastSeen.size === 0 && this.heartbeatTimer) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = undefined;
      }
    }, this.sweepIntervalMs);
  }

  private isRoomExpired(roomId: string): boolean {
    return (this.roomExpiresAt.get(roomId) ?? 0) <= Date.now();
  }

  private findRoomBySocket(socket: WebSocket): string | undefined {
    return this.sessions.get(socket)?.roomId;
  }

  private generateRoomId(): string {
    for (let attempt = 0; attempt < 100; attempt++) {
      let value = "";
      const bytes = new Uint8Array(6);
      crypto.getRandomValues(bytes);
      for (const byte of bytes) {
        value += ROOM_CODE_ALPHABET[byte % ROOM_CODE_ALPHABET.length];
      }
      if (!this.rooms.has(value)) {
        return value;
      }
    }
    throw new Error("failed to allocate room id");
  }

  private createRoomUser(info: ClientInfo, isCreator: boolean): RoomUser {
    const connectionId = crypto.randomUUID();
    return {
      connectionId,
      shortId: connectionId.slice(0, 8),
      app: info.app,
      platform: info.platform,
      version: info.version,
      isCreator
    };
  }

  private send(socket: WebSocket, payload: unknown): void {
    try {
      socket.send(JSON.stringify(payload));
    } catch {
      this.removeSocket(socket);
    }
  }

  private sendError(
    socket: WebSocket,
    requestId: string | undefined,
    code: string,
    message: string
  ): void {
    this.send(socket, {
      type: "error",
      requestId,
      error: { code, message }
    });
  }

  private safeClose(socket: WebSocket, code: number, reason: string): void {
    try {
      socket.close(code, reason);
    } catch {
      // ignored
    }
  }

  private recordMetric(socket: WebSocket, type: UsageMetricEventType): void {
    this.metricsSink.record(
      { type },
      this.connectionContexts.get(socket) ?? {},
      Date.now()
    );
  }

  dispose(reason = "serverShutdown"): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = undefined;
    }
    for (const socket of [...this.lastSeen.keys()]) {
      this.send(socket, { type: "roomDestroyed", reason });
      this.safeClose(socket, 1001, "server shutdown");
    }
    this.sessions.clear();
    this.rooms.clear();
    this.roomCreators.clear();
    this.roomExpiresAt.clear();
    this.lastSeen.clear();
    this.connectionContexts.clear();
  }
}

export class RoomHub {
  private readonly core: RoomHubCore;

  constructor(state: DurableObjectState, env: Env) {
    this.core = new RoomHubCore({
      metricsSink: new CloudflareMetricsSink(state, env)
    });
  }

  async fetch(request: Request): Promise<Response> {
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    server.accept();
    this.core.attachSocket(server, true, {
      source: "cloudflare",
      visitorHash: request.headers.get(INTERNAL_VISITOR_HEADER) ?? undefined,
      countryCode: request.headers.get(INTERNAL_COUNTRY_HEADER) ?? "ZZ",
      regionCode: request.headers.get(INTERNAL_REGION_HEADER) ?? "",
      isProbe: false
    });
    return new Response(null, { status: 101, webSocket: client });
  }
}

export class MetricsHub {
  private store?: SqlMetricsStore;
  private readonly availabilityTarget: string;

  constructor(
    private readonly state: DurableObjectState,
    private readonly env: Env
  ) {
    this.availabilityTarget = normalizeSelfOrigin(
      env.SELF_ORIGIN ?? "https://simple-live-sync.3439394104.workers.dev"
    );
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    if (url.pathname === "/internal/record") {
      if (request.method !== "POST") {
        return json({ status: false, message: "method not allowed" }, 405);
      }
      if (!metricsEnabled(this.env)) {
        return new Response(null, { status: 204 });
      }
      try {
        const body = (await request.json()) as {
          event?: MetricsEvent;
          context?: ConnectionContext;
          occurredAt?: number;
        };
        if (!body.event) {
          throw new TypeError("metrics event is required");
        }
        this.metricsStore().write([
          createMetricRecord(body.event, body.context, body.occurredAt ?? Date.now())
        ]);
        return new Response(null, { status: 204 });
      } catch (error) {
        return json({ status: false, message: stringifyError(error) }, 400);
      }
    }
    if (url.pathname === "/internal/probe") {
      if (request.method !== "POST") {
        return json({ status: false, message: "method not allowed" }, 405);
      }
      if (!metricsEnabled(this.env)) {
        return new Response(null, { status: 204 });
      }
      const occurredAt = Date.now();
      const event = await runCloudflareAvailabilityProbe(this.availabilityTarget);
      this.metricsStore().write(
        [
          createMetricRecord(
            event,
            { source: "cloudflare", isProbe: true },
            occurredAt
          )
        ],
        { receivedAt: Date.now() }
      );
      return json({ status: true, availability: event });
    }
    if (isStatsApiPath(url.pathname)) {
      const methodError = statsMethodError(request.method);
      if (methodError) {
        return methodError;
      }
      if (!metricsEnabled(this.env)) {
        return json(
          { status: false, message: "statistics are temporarily unavailable" },
          503,
          "no-store"
        );
      }
      const result = queryStatsApi(this.metricsStore(), url, this.availabilityTarget);
      return json(
        result.payload,
        result.status,
        result.status === 200 ? STATS_CACHE_CONTROL : "no-store"
      );
    }
    return json({ status: false, message: "not found" }, 404);
  }

  private metricsStore(): SqlMetricsStore {
    this.store ??= new SqlMetricsStore(
      new DurableObjectSqlAdapter(this.state.storage),
      { source: "cloudflare" }
    );
    return this.store;
  }
}

class CloudflareMetricsSink implements MetricsSink {
  constructor(
    private readonly state: DurableObjectState,
    private readonly env: Env
  ) {}

  record(
    event: MetricsEvent,
    context: ConnectionContext = {},
    occurredAt: number | Date = Date.now()
  ): void {
    if (!metricsEnabled(this.env)) {
      return;
    }
    const record = createMetricRecord(
      event,
      { ...context, source: "cloudflare" },
      occurredAt
    );
    this.state.waitUntil(
      metricsStub(this.env)
        .fetch("https://metrics.internal/internal/record", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(record)
        })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`metrics write returned ${response.status}`);
          }
        })
        .catch((error) => console.error("Metrics write failed", stringifyError(error)))
    );
  }
}

export function buildHealthPayload(): Record<string, unknown> {
  return {
    status: true,
    message: "simple live sync server is running",
    version: VERSION,
    now: new Date().toISOString(),
    limits: {
      roomTtlSeconds: ROOM_TTL_MS / 1000,
      maxRoomClients: MAX_ROOM_CLIENTS,
      maxMessageBytes: MAX_MESSAGE_BYTES
    },
    endpoints: {
      home: "/",
      health: "/health",
      sync: "/sync"
    }
  };
}

function html(body: string, status = 200): Response {
  return new Response(body, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "public, max-age=120"
    }
  });
}

function javascript(body: string): Response {
  return new Response(body, {
    headers: {
      "content-type": "application/javascript; charset=utf-8",
      "cache-control": "public, max-age=300"
    }
  });
}

export function renderHomePage(origin: string): string {
  const syncUrl = `${origin.replace(/^http/, "ws")}/sync`;
  const canonicalSyncUrl = `${DEFAULT_SERVICE_ORIGIN.replace(/^http/, "ws")}/sync`;
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Simple Live Sync</title>
  <meta name="description" content="Simple Live 远程同步临时房间服务状态页" />
  <style>
    :root {
      color-scheme: light dark;
      --bg: #f6f7f4;
      --panel: #ffffff;
      --panel-soft: #eef3ef;
      --text: #17201a;
      --muted: #667067;
      --line: #dce3dd;
      --brand: #127c5b;
      --brand-dark: #0d5f48;
      --accent: #d7832f;
      --ok: #15915f;
      --warn: #b66a14;
      --shadow: 0 18px 50px rgba(23, 32, 26, .10);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
    }
    @media (prefers-color-scheme: dark) {
      :root {
        --bg: #101411;
        --panel: #171d19;
        --panel-soft: #1d2721;
        --text: #eaf0eb;
        --muted: #a2aea6;
        --line: #2c3931;
        --brand: #4cc49a;
        --brand-dark: #78ddb9;
        --accent: #e2a04f;
        --shadow: 0 18px 50px rgba(0, 0, 0, .26);
      }
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); }
    a { color: var(--brand-dark); text-decoration: none; }
    a:hover { text-decoration: underline; }
    .shell { width: min(1120px, calc(100% - 32px)); margin: 0 auto; }
    header { padding: 28px 0 18px; display: flex; align-items: center; justify-content: space-between; gap: 18px; }
    .brand { display: flex; align-items: center; gap: 12px; font-weight: 750; }
    .mark { width: 36px; height: 36px; border-radius: 8px; display: grid; place-items: center; color: white; background: linear-gradient(135deg, var(--brand), #325a9f); font-weight: 900; }
    nav { display: flex; gap: 14px; flex-wrap: wrap; font-size: 14px; color: var(--muted); }
    .hero { padding: 34px 0 24px; display: grid; grid-template-columns: minmax(0, 1.25fr) minmax(320px, .75fr); gap: 22px; align-items: stretch; }
    .hero-main, .card, .status-card { background: var(--panel); border: 1px solid var(--line); border-radius: 8px; box-shadow: var(--shadow); }
    .hero-main { padding: clamp(24px, 4vw, 42px); }
    .eyebrow { display: inline-flex; align-items: center; gap: 8px; padding: 6px 10px; border-radius: 999px; background: var(--panel-soft); color: var(--brand-dark); font-size: 13px; font-weight: 700; }
    h1 { margin: 18px 0 14px; font-size: clamp(34px, 7vw, 72px); line-height: .96; letter-spacing: 0; }
    .lead { margin: 0; max-width: 720px; color: var(--muted); font-size: clamp(16px, 2.2vw, 20px); line-height: 1.7; }
    .actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 28px; }
    button, .button { border: 0; border-radius: 8px; padding: 11px 15px; font: inherit; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
    .primary { background: var(--brand); color: #fff; }
    .secondary { background: var(--panel-soft); color: var(--text); border: 1px solid var(--line); }
    .status-card { padding: 22px; display: flex; flex-direction: column; gap: 16px; }
    .status-line { display: flex; justify-content: space-between; gap: 14px; align-items: center; }
    .pill { border-radius: 999px; padding: 6px 10px; font-size: 13px; font-weight: 750; background: rgba(21,145,95,.12); color: var(--ok); }
    .metric { padding: 14px; background: var(--panel-soft); border-radius: 8px; border: 1px solid var(--line); }
    .metric span { display: block; color: var(--muted); font-size: 13px; margin-bottom: 4px; }
    code { word-break: break-all; font-family: ui-monospace, SFMono-Regular, Consolas, "Liberation Mono", monospace; font-size: .92em; }
    .grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 18px; margin: 20px 0; }
    .card { padding: 22px; box-shadow: none; }
    .card h2, .card h3 { margin: 0 0 12px; letter-spacing: 0; }
    .card p, .card li { color: var(--muted); line-height: 1.65; }
    .card ul, .card ol { padding-left: 20px; margin: 10px 0 0; }
    .wide { grid-column: span 2; }
    .downloads { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .download { padding: 14px; border: 1px solid var(--line); border-radius: 8px; background: var(--panel-soft); }
    .download strong { display: block; margin-bottom: 6px; }
    .diag { margin-top: 12px; padding: 12px; border-radius: 8px; border: 1px solid var(--line); background: var(--panel-soft); min-height: 48px; color: var(--muted); }
    footer { padding: 28px 0 46px; color: var(--muted); font-size: 14px; }
    @media (max-width: 860px) {
      header, .hero { grid-template-columns: 1fr; }
      header { align-items: flex-start; flex-direction: column; }
      .grid, .downloads { grid-template-columns: 1fr; }
      .wide { grid-column: auto; }
    }
  </style>
</head>
<body>
  <div class="shell">
    <header>
      <div class="brand"><div class="mark">SL</div><span>Simple Live Sync</span></div>
      <nav>
        <a href="/stats">统计</a>
        <a href="#usage">使用</a>
        <a href="#diagnostics">检测</a>
        <a href="#privacy">隐私</a>
        <a href="https://github.com/June6699/dart_simple_live/releases">下载</a>
      </nav>
    </header>

    <main>
      <section class="hero">
        <div class="hero-main">
          <span class="eyebrow">远程同步临时房间服务</span>
          <h1>Simple Live Sync</h1>
          <p class="lead">用于 Simple Live App 和 TV 端之间临时同步关注、历史、屏蔽词和账号配置。服务只做 WebSocket 转发，不保存同步内容。</p>
          <div class="actions">
            <button class="primary" id="run-check">检测服务</button>
            <a class="button secondary" href="/health">查看 /health</a>
            <a class="button secondary" href="/stats">查看调用统计</a>
          </div>
        </div>
        <aside class="status-card" id="diagnostics">
          <div class="status-line"><strong>服务状态</strong><span class="pill" id="status-pill">等待检测</span></div>
          <div class="metric"><span>HTTP endpoint</span><code>${escapeHtml(origin)}/health</code></div>
          <div class="metric"><span>WebSocket endpoint</span><code>${escapeHtml(syncUrl)}</code></div>
          <div class="metric"><span>App 默认 endpoint</span><code>${escapeHtml(canonicalSyncUrl)}</code></div>
          <div class="metric"><span>本地永久总调用</span><strong id="home-total-calls">—</strong></div>
          <div class="metric"><span>近 30 天可用率</span><strong id="home-availability">—</strong></div>
          <div class="diag" id="diag-output">点击“检测服务”后会检查 /health 和 WebSocket ping/pong。</div>
        </aside>
      </section>

      <section class="grid" id="usage">
        <article class="card">
          <h2>怎么使用</h2>
          <ol>
            <li>在一台设备中打开远程同步并创建房间。</li>
            <li>另一台设备扫码或输入房间号加入。</li>
            <li>选择要同步的关注、历史、屏蔽词或账号配置。</li>
          </ol>
        </article>
        <article class="card">
          <h2>服务限制</h2>
          <ul>
            <li>房间有效期 600 秒。</li>
            <li>创建者断开后房间销毁。</li>
            <li>单房间最多 8 个连接。</li>
            <li>单条消息最大 1 MB。</li>
          </ul>
        </article>
        <article class="card">
          <h2>常见失败原因</h2>
          <ul>
            <li>网络无法访问所选同步服务。</li>
            <li>代理或防火墙拦截 WebSocket。</li>
            <li>房间已过期或创建者已离开。</li>
          </ul>
        </article>
        <article class="card wide" id="privacy">
          <h2>隐私说明</h2>
          <p>该服务不保存关注列表、观看历史、Cookie、屏蔽词或其他同步内容。同步数据只在同一个临时房间内通过 WebSocket 转发，房间过期或创建者断开后即销毁。调用统计仅保存 HMAC 匿名访客标识及国家/中国省级聚合，匿名明细保留 90 天；自建服务器的常规 Nginx 访问日志仍按运维策略独立轮转。</p>
        </article>
        <article class="card">
          <h2>自建服务</h2>
          <p>该仓库同时支持 Cloudflare Worker 和 Node.js 自建部署。部署完成后，在 App 的同步服务设置中填写自己的 <code>wss://.../sync</code>。</p>
        </article>
      </section>

      <section class="card">
        <h2>下载</h2>
        <div class="downloads">
          <a class="download" href="https://github.com/June6699/dart_simple_live/releases/tag/v1.12.7"><strong>Simple Live v1.12.7</strong><span>Android / Windows / Linux</span></a>
          <a class="download" href="https://github.com/June6699/dart_simple_live/releases/tag/tv_v1.7.8"><strong>Simple Live TV tv_v1.7.8</strong><span>Android TV APK</span></a>
        </div>
      </section>
    </main>

    <footer>Simple Live Sync · Version ${escapeHtml(VERSION)} · <a href="/stats">本地统计</a> · <a href="https://github.com/June6699/dart_simple_live">GitHub</a></footer>
  </div>
  <script src="/assets/app.js" defer></script>
</body>
</html>`;
}

export function renderHealthPage(origin: string): string {
  const payload = buildHealthPayload();
  const syncUrl = `${origin.replace(/^http/, "ws")}/sync`;
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Simple Live Sync Health</title>
  <style>
    :root { color-scheme: light dark; --bg:#f6f7f4; --panel:#fff; --soft:#eef3ef; --text:#17201a; --muted:#667067; --line:#dce3dd; --ok:#15915f; --brand:#127c5b; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif; }
    @media (prefers-color-scheme: dark) { :root { --bg:#101411; --panel:#171d19; --soft:#1d2721; --text:#eaf0eb; --muted:#a2aea6; --line:#2c3931; --brand:#4cc49a; } }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; background: var(--bg); color: var(--text); }
    main { width: min(760px, 100%); background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: clamp(22px, 5vw, 38px); box-shadow: 0 18px 50px rgba(23,32,26,.10); }
    a { color: var(--brand); text-decoration: none; font-weight: 700; }
    a:hover { text-decoration: underline; }
    .top { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; }
    .pill { padding: 7px 11px; border-radius: 999px; background: rgba(21,145,95,.12); color: var(--ok); font-weight: 800; font-size: 14px; }
    h1 { margin: 18px 0 8px; font-size: clamp(30px, 7vw, 54px); line-height: 1; letter-spacing: 0; }
    p { color: var(--muted); line-height: 1.7; }
    .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin: 22px 0; }
    .metric { padding: 14px; border: 1px solid var(--line); border-radius: 8px; background: var(--soft); }
    .metric span { display: block; color: var(--muted); font-size: 13px; margin-bottom: 5px; }
    code { word-break: break-all; font-family: ui-monospace, SFMono-Regular, Consolas, "Liberation Mono", monospace; }
    .actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 22px; }
    .button { display: inline-flex; align-items: center; justify-content: center; min-height: 42px; border-radius: 8px; padding: 0 14px; background: var(--brand); color: white; text-decoration: none; }
    .button.secondary { background: var(--soft); color: var(--text); border: 1px solid var(--line); }
    @media (max-width: 620px) { .grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <main>
    <div class="top"><strong>Simple Live Sync</strong><span class="pill">ONLINE</span></div>
    <h1>服务正常</h1>
    <p>远程同步服务正在运行。App 使用 <code>/sync</code> WebSocket 端点创建或加入临时同步房间。</p>
    <div class="grid">
      <div class="metric"><span>Version</span><code>${escapeHtml(String(payload.version))}</code></div>
      <div class="metric"><span>Checked At</span><code>${escapeHtml(String(payload.now))}</code></div>
      <div class="metric"><span>Room TTL</span><code>${ROOM_TTL_MS / 1000} seconds</code></div>
      <div class="metric"><span>Max Clients</span><code>${MAX_ROOM_CLIENTS}</code></div>
      <div class="metric"><span>Health JSON</span><code>${escapeHtml(origin)}/health?format=json</code></div>
      <div class="metric"><span>WebSocket</span><code>${escapeHtml(syncUrl)}</code></div>
    </div>
    <div class="actions">
      <a class="button" href="/">返回首页</a>
      <a class="button secondary" href="/health?format=json">查看 JSON</a>
    </div>
  </main>
</body>
</html>`;
}

function wantsHtml(request: Request, url: URL): boolean {
  if (url.searchParams.get("format") === "json") {
    return false;
  }
  if (url.searchParams.get("format") === "html") {
    return true;
  }
  return request.headers.get("accept")?.includes("text/html") === true;
}

export function renderAppScript(): string {
  return `const button = document.getElementById("run-check");
const output = document.getElementById("diag-output");
const pill = document.getElementById("status-pill");
const totalCalls = document.getElementById("home-total-calls");
const availability = document.getElementById("home-availability");

function setStatus(text, ok) {
  pill.textContent = text;
  pill.style.color = ok ? "var(--ok)" : "var(--warn)";
}

function line(text) {
  output.textContent += (output.textContent ? "\\n" : "") + text;
}

async function checkHealth() {
  const started = performance.now();
  const response = await fetch("/health", { cache: "no-store" });
  const data = await response.json();
  if (!response.ok || data.status !== true) {
    throw new Error("/health returned an unhealthy response");
  }
  line("/health OK · " + Math.round(performance.now() - started) + " ms · version " + data.version);
}

function checkWebSocket() {
  return new Promise((resolve, reject) => {
    const wsUrl = location.origin.replace(/^http/, "ws") + "/sync";
    const ws = new WebSocket(wsUrl);
    const requestId = "web-" + Date.now();
    const timer = setTimeout(() => {
      ws.close();
      reject(new Error("WebSocket ping timeout"));
    }, 6000);
    ws.onopen = () => ws.send(JSON.stringify({ type: "ping", requestId }));
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "pong" && data.requestId === requestId) {
        clearTimeout(timer);
        line("WebSocket OK · ping/pong received");
        ws.close();
        resolve();
      }
    };
    ws.onerror = () => {
      clearTimeout(timer);
      reject(new Error("WebSocket connection failed"));
    };
  });
}

async function loadStatsSummary() {
  try {
    const response = await fetch("/api/stats/summary");
    if (!response.ok) {
      throw new Error("statistics unavailable");
    }
    const data = await response.json();
    const integer = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 0 });
    if (totalCalls) {
      totalCalls.textContent = integer.format(Number(data.totalCalls) || 0);
    }
    if (availability) {
      availability.textContent = data.availability30d == null
        ? "待积累"
        : new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 2 }).format(Number(data.availability30d)) + "%";
    }
  } catch {
    if (totalCalls) totalCalls.textContent = "暂不可用";
    if (availability) availability.textContent = "暂不可用";
  }
}

button?.addEventListener("click", async () => {
  output.textContent = "";
  setStatus("检测中", true);
  button.disabled = true;
  try {
    await checkHealth();
    await checkWebSocket();
    setStatus("在线", true);
  } catch (error) {
    line("检测失败 · " + (error instanceof Error ? error.message : String(error)));
    setStatus("异常", false);
  } finally {
    button.disabled = false;
  }
});

void loadStatsSummary();`;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function json(payload: unknown, status = 200, cacheControl = "no-store"): Response {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": cacheControl
    }
  });
}

function statsMethodError(method: string): Response | undefined {
  if (method === "GET" || method === "HEAD") {
    return undefined;
  }
  const response = json(
    { status: false, message: "method not allowed" },
    405,
    "no-store"
  );
  response.headers.set("allow", "GET, HEAD");
  return response;
}

function parseClientInfo(raw: unknown): ClientInfo | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const value = raw as Record<string, unknown>;
  const app = safeText(value.app, 40);
  const platform = safeText(value.platform, 40);
  const version = safeText(value.version, 40);
  if (!app || !platform || !version) {
    return null;
  }
  return { app, platform, version };
}

function parseSyncPayload(raw: unknown): { overlay: boolean; content: string } | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const value = raw as Record<string, unknown>;
  const content = typeof value.content === "string" ? value.content : "";
  if (!content) {
    return null;
  }
  return {
    overlay: value.overlay === true,
    content
  };
}

function normalizeRoomId(raw: unknown): string | null {
  if (typeof raw !== "string") {
    return null;
  }
  const value = raw.trim().toUpperCase();
  return /^[A-Z0-9]{4,12}$/.test(value) ? value : null;
}

function safeText(raw: unknown, maxLength: number): string {
  if (typeof raw !== "string") {
    return "";
  }
  return raw.trim().slice(0, maxLength);
}

function stringifyError(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}

function metricsStub(env: Env): DurableObjectStub {
  return env.METRICS.get(env.METRICS.idFromName("global-metrics-hub"));
}

function metricsEnabled(env: Env): boolean {
  return env.METRICS_ENABLED?.trim().toLowerCase() !== "false";
}

function assetRequest(request: Request, pathname: string): Request {
  const url = new URL(request.url);
  url.pathname = pathname;
  url.search = "";
  return new Request(url.toString(), {
    method: request.method,
    headers: request.headers
  });
}

async function cloudflareConnectionContext(
  request: Request,
  env: Env
): Promise<ConnectionContext> {
  const cf = (request.cf ?? {}) as Record<string, unknown>;
  const countryCode = normalizeCountryCode(cf.country);
  const regionCode = normalizeRegionCode(cf.regionCode);
  const ip = request.headers.get("CF-Connecting-IP")?.trim();
  return {
    source: "cloudflare",
    countryCode,
    regionCode,
    visitorHash:
      ip && env.IP_HASH_SECRET ? await hmacSha256(env.IP_HASH_SECRET, ip) : undefined,
    isProbe: false
  };
}

let cachedHmacKey: { secret: string; key: CryptoKey } | undefined;

async function hmacSha256(secret: string, value: string): Promise<string> {
  let key = cachedHmacKey?.secret === secret ? cachedHmacKey.key : undefined;
  if (!key) {
    key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    cachedHmacKey = { secret, key };
  }
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(value)
  );
  return [...new Uint8Array(signature)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function normalizeSelfOrigin(value: string): string {
  const url = new URL(value.trim());
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new TypeError("SELF_ORIGIN must use http or https");
  }
  return url.origin;
}

async function runCloudflareAvailabilityProbe(origin: string): Promise<MetricsEvent> {
  const [http, websocket] = await Promise.all([
    probeCloudflareHttp(origin),
    probeCloudflareWebSocket(origin)
  ]);
  return {
    type: "availability_check",
    target: origin,
    httpOk: http.ok,
    websocketOk: websocket.ok,
    httpLatencyMs: http.latencyMs,
    websocketLatencyMs: websocket.latencyMs,
    errorCode: [http.error, websocket.error].filter(Boolean).join(";").slice(0, 80) || undefined
  };
}

type ProbeResult = { ok: boolean; latencyMs?: number; error?: string };

async function probeCloudflareHttp(origin: string): Promise<ProbeResult> {
  const startedAt = Date.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch(`${origin}/health?format=json`, {
      signal: controller.signal
    });
    const payload = (await response.json()) as { status?: unknown };
    if (!response.ok || payload.status !== true) {
      throw new Error(`HTTP ${response.status}`);
    }
    return { ok: true, latencyMs: Date.now() - startedAt };
  } catch (error) {
    return { ok: false, error: `http:${shortProbeError(error)}` };
  } finally {
    clearTimeout(timeout);
  }
}

async function probeCloudflareWebSocket(origin: string): Promise<ProbeResult> {
  const startedAt = Date.now();
  const controller = new AbortController();
  const fetchTimeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch(`${origin}/sync`, {
      headers: { Upgrade: "websocket" },
      signal: controller.signal
    });
    const socket = response.webSocket;
    if (!socket) {
      throw new Error(`upgrade:${response.status}`);
    }
    clearTimeout(fetchTimeout);
    socket.accept();
    const requestId = `availability-${crypto.randomUUID()}`;
    return await new Promise<ProbeResult>((resolve) => {
      let settled = false;
      const finish = (result: ProbeResult) => {
        if (settled) {
          return;
        }
        settled = true;
        clearTimeout(timeout);
        try {
          socket.close(1000, "probe complete");
        } catch {
          // ignored
        }
        resolve(result);
      };
      const timeout = setTimeout(
        () => finish({ ok: false, error: "ws:timeout" }),
        Math.max(1, 10_000 - (Date.now() - startedAt))
      );
      socket.addEventListener("message", (event) => {
        try {
          const payload = JSON.parse(String(event.data)) as {
            type?: unknown;
            requestId?: unknown;
          };
          if (payload.type === "pong" && payload.requestId === requestId) {
            finish({ ok: true, latencyMs: Date.now() - startedAt });
          }
        } catch {
          // Ignore unrelated messages while waiting for pong.
        }
      });
      socket.addEventListener("error", () =>
        finish({ ok: false, error: "ws:error" })
      );
      socket.addEventListener("close", () =>
        finish({ ok: false, error: "ws:closed" })
      );
      socket.send(JSON.stringify({ type: "ping", requestId }));
    });
  } catch (error) {
    return { ok: false, error: `ws:${shortProbeError(error)}` };
  } finally {
    clearTimeout(fetchTimeout);
  }
}

function shortProbeError(error: unknown): string {
  if (error instanceof Error) {
    return error.name === "AbortError" ? "timeout" : error.message.slice(0, 40);
  }
  return String(error).slice(0, 40);
}
