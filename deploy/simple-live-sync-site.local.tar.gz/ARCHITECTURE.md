# Simple Live Sync 架构说明

本文档记录 `simple-live-sync-site` 当前架构、数据流、统计设计和部署边界。它面向后续维护与排障，避免把 Cloudflare Worker、自建 Node 服务、统计库、GeoIP 和可用性监控混在一起理解。

## 设计目标

- 保留现有 `/`、`/health`、`/sync` 行为和 WebSocket 房间协议，不破坏 Simple Live 客户端兼容性。
- Cloudflare Worker 与 `sync.furry.mo.cn` 自建 Node 服务互相独立，房间状态和统计数据均不共享。
- 房间转发路径优先保证低延迟和可用性；统计写入必须 fail-open，不能影响建房、入房或同步消息。
- 统计只记录成功业务动作、匿名访客哈希、国家/中国省级聚合和可用性探测结果，不保存原始 IP 或同步内容。
- `/stats` 是公开只读统计面板，API 只返回聚合数据和匿名计数。

## 总体拓扑

```mermaid
flowchart LR
  subgraph Client[Simple Live 客户端]
    App[App / TV]
  end

  subgraph CF[Cloudflare 部署]
    Worker[Worker: src/index.ts]
    RoomDO[RoomHub Durable Object]
    MetricsDO[MetricsHub Durable Object]
    AssetsCF[Cloudflare Assets: public/]
  end

  subgraph NodeHost[sync.furry.mo.cn 自建部署]
    Nginx[Nginx TLS / GeoIP2 / 反代]
    Node[Node 22: dist/server.js]
    Core[RoomHubCore]
    Queue[内存指标队列]
    SQLite[(SQLite metrics.sqlite)]
    GeoIP[(GeoLite2-City.mmdb)]
  end

  App -->|wss /sync| Worker
  Worker --> RoomDO
  Worker --> MetricsDO
  Worker --> AssetsCF

  App -->|https/wss sync.furry.mo.cn| Nginx
  Nginx -->|可信 IP/Geo headers| Node
  Nginx --> GeoIP
  Node --> Core
  Core --> Queue
  Queue --> SQLite
```

## 运行时边界

| 组件 | 文件/配置 | 职责 |
| --- | --- | --- |
| 共享房间核心 | `src/index.ts` 中的 `RoomHubCore` | 解析 WebSocket 消息、维护房间、广播用户列表、转发四类同步内容、记录成功业务动作。 |
| Cloudflare Worker | `src/index.ts`、`wrangler.toml` | 提供首页、健康检查、静态资源、统计 API 代理、WebSocket 入口、Cron 自检入口。 |
| Cloudflare 房间 DO | `RoomHub` Durable Object | 持有 Cloudflare 侧的全局房间状态。 |
| Cloudflare 统计 DO | `MetricsHub` Durable Object | 使用 DO SQLite 保存 Cloudflare 侧统计和可用性记录。 |
| Node HTTP/WS 服务 | `src/server.ts` | 提供自建站点路由、WebSocket upgrade、静态资源、统计 API、Node 自检调度。 |
| Node 统计服务 | `src/metrics-node.ts` | 使用 `node:sqlite`、内存队列、5 秒或 100 条批量事务写入。 |
| 统计 Store | `src/metrics-store.ts` | 统一 SQL 写入、清理、汇总、时间线、地理和可用性查询。 |
| 统计 API | `src/stats-api.ts` | 白名单校验公开统计 API 参数，统一返回可缓存 JSON。 |
| 统计页面 | `public/stats.html`、`web/stats.ts`、`web/stats.css` | 展示摘要、时间线、事件分布、地图、可用性状态条和延迟趋势。 |
| 自建部署 | `deploy/`、`deploy/nginx/` | 配置 systemd/Docker、Nginx、GeoIP、备份、smoke 和验证脚本。 |

## 公开路由

| 路由 | Cloudflare | Node | 说明 |
| --- | --- | --- | --- |
| `GET /` | Worker HTML | Node HTML | 首页，含健康检测、统计摘要入口。 |
| `GET /health` | Worker JSON/HTML | Node JSON/HTML | 同步服务健康检查；统计库故障不影响健康语义。 |
| `GET /stats` | Assets `stats.html` | `public/stats.html` | 公开统计面板。 |
| `GET /assets/*` | Cloudflare Assets | 本地 `public/assets/*` | 统计 JS/CSS、地图资源、许可证说明。 |
| `GET /api/stats/summary` | MetricsHub | SQLite Store | 总调用、近 24 小时、近 30 天独立 IP、近 30 天可用率。 |
| `GET /api/stats/timeline?range=24h\|7d\|30d\|90d\|all` | MetricsHub | SQLite Store | 成功业务调用时间线；`all` 仅用于趋势。 |
| `GET /api/stats/geo?range=24h\|7d\|30d\|90d` | MetricsHub | SQLite Store | 国家和中国省级地理聚合。 |
| `GET /api/stats/availability?range=24h\|7d\|30d\|90d` | MetricsHub | SQLite Store | 小时可用性状态和延迟。 |
| `GET /sync` | 426 | 426 | 普通 HTTP 访问提示需要 WebSocket upgrade。 |
| `WS /sync` | RoomHub DO | RoomHubCore | 房间协议入口。 |

统计 API 响应使用 `Cache-Control: public, max-age=60, stale-while-revalidate=300`。不支持的 query 参数或范围返回 400。

## WebSocket 房间协议

房间逻辑由 `RoomHubCore` 统一实现，两端共用同一套行为：

- `ping` 返回 `pong`，不计入业务调用。
- `createRoom` 成功后返回 `roomCreated`，记录 `room_created`。
- `joinRoom` 成功后返回 `roomJoined`，记录 `room_joined`。
- `sendFavorite`、`sendHistory`、`sendShieldWord`、`sendBiliAccount` 成功转发后返回 `ack`，分别记录四类同步事件。
- 失败请求、非法 JSON、超大 payload、健康检查、自检探针和页面访问均不计入总调用。
- 房间 TTL 为 600 秒；创建者断开会销毁房间；单房间最多 8 个连接；单消息最大 1 MB。
- 同步内容只在内存中的房间内转发，不进入统计库、日志或公开 API。

## 指标写入链路

```mermaid
sequenceDiagram
  participant Client as 客户端
  participant Hub as RoomHubCore
  participant Sink as MetricsSink
  participant Store as Metrics Store

  Client->>Hub: createRoom / joinRoom / send*
  Hub-->>Client: 成功响应
  Hub->>Sink: record(success event, connection context)
  Sink-->>Hub: 立即返回或异步 waitUntil
  Sink->>Store: 聚合写入
```

Cloudflare 与 Node 的写入方式不同：

- Cloudflare 侧通过 `CloudflareMetricsSink` 调用独立 `MetricsHub` Durable Object，使用 `state.waitUntil` 异步写入。
- Node 侧通过 `NodeMetricsService` 进入内存队列，默认 5 秒或 100 条触发 SQLite 事务写入，进程正常退出时 flush。
- 两端都通过 `createFailOpenMetricsSink` 包裹统计写入；统计异常只记录错误，不影响 WebSocket 响应。

## 统计存储模型

统计 schema 定义在 `src/metrics-schema.ts`，由 `SqlMetricsStore` 统一使用：

| 表 | 保留策略 | 内容 |
| --- | --- | --- |
| `metrics_meta` | 永久 | schema、清理时间、监控启用时间等元数据。 |
| `metrics_totals` | 永久 | 六类成功业务事件的永久累计。 |
| `metrics_hourly` | 90 天 | 按 UTC 小时聚合的事件计数。 |
| `metrics_daily` | 永久 | 按 UTC 日期聚合的事件计数。 |
| `metrics_geo_daily` | 永久 | 国家/省级维度的日级调用计数。 |
| `metrics_visitors_daily` | 90 天 | 匿名访客哈希的日级去重明细。 |
| `availability_hourly` | 90 天 | 每小时 HTTP/WS 状态、延迟样本和状态等级。 |
| `availability_daily` | 永久 | 日级可用性汇总。 |

小时明细、匿名访客明细和小时可用性只保留 90 天；永久总量、日级趋势、地理日汇总和日级可用性长期保留。Schema 按向前兼容的增量方式演进，不做破坏性迁移。

## IP、GeoIP 与隐私

原始 IP 只在请求边界使用：

- Cloudflare 侧读取可信 `request.cf.country`、`request.cf.regionCode` 和 `CF-Connecting-IP`，后者只用于 HMAC。
- Node 侧只在连接来自 loopback Nginx 时信任 `X-Real-IP`、`X-Geo-Country`、`X-Geo-Region`。
- Nginx 使用 GeoIP2 从 `GeoLite2-City.mmdb` 派生国家码和一级行政区码，并覆盖 `X-Real-IP`、`X-Forwarded-For`、`X-Geo-Country`、`X-Geo-Region`，清空客户端伪造的 `Forwarded`、`CF-Connecting-IP` 和 `True-Client-IP`。
- 原始 IP 不写入 SQLite/DO，不返回给前端；匿名访客哈希由各端独立 `IP_HASH_SECRET` 生成。
- 未识别地区统一记为 `ZZ`，前端表格显示“未知地区”，地图不错误着色。

GeoIP 文件来源：

- 服务器需要 `/etc/GeoIP.conf`，文件包含 MaxMind 凭据，必须 root-owned、`0600`，不提交仓库。
- `GeoLite2-City.mmdb` 放在 `/var/lib/GeoIP/GeoLite2-City.mmdb`。
- `simple-live-sync-geoipupdate.timer` 每日更新；Nginx `auto_reload 1h` 自动加载新版数据库。
- 仓库仅提交 `deploy/geoipupdate.conf.example` 和地图许可证说明，不提交真实凭据或 MaxMind 数据库。
- 若 MaxMind 官方下载因地区或账号策略失败，可手工安装兼容的 `GeoLite2-City.mmdb` 到同一路径，并在运维记录中注明来源、更新时间和许可证。
- 当前应急可用源为 `wp-statistics/GeoLite2-City` / jsDelivr `geolite2-city` 包；它不是 MaxMind 官方分发入口，但提供兼容 MMDB 文件，使用时需保留 MaxMind/CC BY-SA 4.0 归属说明。

## 地图与前端资源

`/stats` 使用本地打包资源，不依赖第三方 CDN：

- ECharts 由 `web/build.mjs` 使用 esbuild 打包到 `public/assets/stats.js`。
- 样式从 `web/stats.css` 打包到 `public/assets/stats.css`。
- 世界边界使用 `public/assets/maps/world-countries-110m.json` 和 `world-countries-50m.json`。
- 中国省级边界使用 `public/assets/maps/china-adm1.geojson` 和 `china-adm1-metadata.json`。
- 地图许可证和来源记录在 `public/assets/maps/LICENSES.md`。

页面默认按独立 IP 着色，也可切换到调用次数。点击中国时下钻到 34 个省级区域；普通国家只显示国家名、独立 IP 和调用次数。地图下方保留同等信息的可排序文本表格，用于可访问性和无地图场景。

## 可用性监控

两端各自监控自己的公开入口：

- Cloudflare：`wrangler.toml` 配置 Cron `5 * * * *`，由 Worker `scheduled` 调用 `MetricsHub /internal/probe`。
- Node：`src/server.ts` 启动后调度每个 UTC 小时第 5 分钟执行 HTTP `/health?format=json` 和 WebSocket `ping/pong`。
- HTTP 与 WebSocket 都成功为 `up`；HTTP 成功但 WebSocket 失败为 `degraded`；明确失败或已结算小时缺记录为 `down`。
- 当前小时在第 15 分钟前显示 `pending`，避免还未完成自检时误判。
- 可用性只从首次监控启用时间开始计算，之前历史不回填为故障。
- 自检事件标记为 probe，不计入总调用次数。

## 配置项

Cloudflare：

| 类型 | 名称 | 说明 |
| --- | --- | --- |
| secret | `IP_HASH_SECRET` | Cloudflare 侧匿名访客哈希盐；不与 Node 共用。 |
| var | `SELF_ORIGIN` | Worker 自检目标 origin。 |
| var | `METRICS_ENABLED` | 统计开关；`false` 时统计写入和 API 可熔断。 |

Node：

| 名称 | 建议值 | 说明 |
| --- | --- | --- |
| `PUBLIC_ORIGIN` | `https://sync.furry.mo.cn` | 自检和页面展示用公开 origin。 |
| `METRICS_ENABLED` | `true` / `false` | 统计熔断开关。 |
| `METRICS_DB_PATH` | `/var/lib/simple-live-sync/metrics.sqlite` | SQLite 指标库路径。 |
| `GEOIP_DB_PATH` | `/var/lib/GeoIP/GeoLite2-City.mmdb` | Nginx/Node 约定的 GeoIP City 数据库路径。 |
| `IP_HASH_SECRET` | 至少 32 字符随机值 | Node 侧匿名访客哈希盐。 |

Node 生产环境通过 `/etc/simple-live-sync/simple-live-sync.env` 注入配置，文件必须 root-owned、`0600`。systemd unit 同时设置 `StateDirectory=simple-live-sync` 与 `UMask=0077`。

## 构建与发布

本地和 CI 验证：

```bash
npm ci
npm run typecheck
npm test
npm run build
```

Cloudflare：

- `master` push 后由 Cloudflare Git 集成自动部署。
- `wrangler.toml` 定义 Worker、Assets、Durable Object 绑定、`v1` 房间 DO migration、`v2` 统计 DO migration 和 Cron。
- `public/assets/stats.js` 与 `stats.css` 是构建产物，默认不提交；Cloudflare build 会运行 `npm run build:web` 生成。

自建 Node：

- Node 服务监听 `127.0.0.1:8787`，Nginx 对外终止 TLS 和代理 `/sync`。
- 支持 Docker Compose 主路径和 systemd Node fallback；两者不能同时占用 8787。
- 发布前执行 `deploy/0.1-preflight.sh`，确认 DNS、Nginx、GeoIP、env、SQLite 和依赖。
- 发布脚本会先构建、备份 SQLite、安装/重启服务，再运行 HTTP 和 WebSocket smoke。
- 重启会清空当前活动房间，但不会删除统计库。

## 故障处理原则

- 同步服务健康以 `/health` 和 WebSocket 协议为准；统计数据库故障不应让 `/health` 失败。
- 统计问题优先设置 `METRICS_ENABLED=false` 熔断，再排查 SQLite/DO/GeoIP/API。
- GeoIP 缺失只影响地理定位和预检，不代表房间协议不可用。
- Cloudflare 和 Node 的统计不合并；排障时先确认用户访问的是哪一个 origin。
- 不在日志、Git、截图或 issue 中暴露 `IP_HASH_SECRET`、`GeoIP.conf`、MaxMind License Key、原始 IP、Cookie 或同步内容。
